Data Annotations:
Chris: Instances 1-50 of test set
Cyprien: Instances 50-100 of test set
Yan: Instances 100-150 of test set
IAA: Yan, Chris did the IAA 

Data Processing and Modelling:
Chris: Wrote pipeline integrating it together, document chunking, 2 scrapers, did prompt testing/tuning, running evals on Colab,
Cyprien: Wrote dense retriever, hybrid retriever, 1 scraper, f1/EM eval file, running evals on colab,
Yan: Wrote sparse BM25 implementation, wrote initial testing suite, running evals on Colab
